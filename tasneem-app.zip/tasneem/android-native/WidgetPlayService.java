package com.tasneem.athkar;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Locale;

/**
 * تشغيل تلاوة آية واحدة من زر ▶ في الودجت — بدون فتح التطبيق.
 * يبث الصوت من everyayah.com (نفس المصدر المستخدم داخل التطبيق، بدون تخزين أو توزيع من عندنا).
 */
public class WidgetPlayService extends Service {

    private static final HashMap<String, String> RECITER_FOLDER = new HashMap<>();
    static {
        RECITER_FOLDER.put("yasser", "Yasser_Ad-Dussary_128kbps");
        RECITER_FOLDER.put("minshawi", "Minshawy_Murattal_128kbps");
        RECITER_FOLDER.put("alafasy", "Alafasy_128kbps");
        RECITER_FOLDER.put("husary", "Husary_128kbps");
    }

    private MediaPlayer mp;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        int surah = intent.getIntExtra("surah", 0);
        int ayah = intent.getIntExtra("ayah", 0);
        if (surah <= 0 || ayah <= 0) { stopSelf(); return START_NOT_STICKY; }

        String reciter = getSharedPreferences(DhikrService.PREFS, MODE_PRIVATE)
                .getString("reciter", "yasser");
        String folder = RECITER_FOLDER.containsKey(reciter) ? RECITER_FOLDER.get(reciter) : RECITER_FOLDER.get("yasser");
        String url = String.format(Locale.US, "https://everyayah.com/data/%s/%03d%03d.mp3", folder, surah, ayah);

        try {
            if (mp != null) { mp.release(); mp = null; }
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setDataSource(url);
            mp.setOnPreparedListener(MediaPlayer::start);
            mp.setOnCompletionListener(p -> stopSelf());
            mp.setOnErrorListener((p, what, extra) -> {
                Toast.makeText(this, "تعذّر تشغيل التلاوة — تأكد من الإنترنت", Toast.LENGTH_SHORT).show();
                stopSelf();
                return true;
            });
            mp.prepareAsync();
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        if (mp != null) { try { mp.release(); } catch (Exception ignored) {} mp = null; }
        super.onDestroy();
    }
}
