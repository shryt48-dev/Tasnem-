/* تسنيم — عامل الخدمة: يخلّي التطبيق يفتح ويشتغل بدون إنترنت */
var CACHE = 'tasneem-v1';
var ASSETS = [
  './', './index.html', './manifest.webmanifest',
  './css/app.css',
  './js/quran-meta.js', './js/adhkar-data.js', './js/prayer-times.js',
  './js/store.js', './js/quran.js', './js/app.js',
  './icons/icon-192.png', './icons/icon-512.png'
];

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return Promise.all(ASSETS.map(function (u) {
        return c.add(u).catch(function () {});   // لا نفشل لو ملف ناقص
      }));
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.map(function (k) { return k === CACHE ? null : caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);

  // نص المصحف بيتخزّن في IndexedDB — نسيبه يعدّي للشبكة
  if (url.pathname.indexOf('quran.json') > -1 || url.hostname.indexOf('alquran') > -1) return;

  // الخطوط: كاش أولًا ثم الشبكة
  var sameOrigin = url.origin === self.location.origin;
  var isFont = url.hostname.indexOf('fonts.g') > -1;
  if (!sameOrigin && !isFont) return;

  e.respondWith(
    caches.match(req).then(function (hit) {
      if (hit) return hit;
      return fetch(req).then(function (res) {
        if (res && res.status === 200) {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put(req, copy); });
        }
        return res;
      }).catch(function () {
        return caches.match('./index.html');
      });
    })
  );
});
